Testing Environment
===================

The testing environment expects to have [Xampp] installed in `/opt/lampp` with default user `nobody` and password `lampp` settings. 
It uses root permissions to start and stop the FTP server. 

To run the unit tests, you have to run `make` in this directory.
    

[Xampp]: http://www.apachefriends.org/en/xampp.html
